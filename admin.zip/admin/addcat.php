<?php
include 'co.php';
session_start();

include 'headers.html';

?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="reg.css">
<script type="text/javascript">
    
    function formValidation()
{


  var a=document.forms["registration"]["cat_name"].value;
if(a=="")
{
alert("Please Fill Catogory Field");
document.getElementById('cat_name').focus();
return false;
}
if ((a.length < 3) || (a.length > 30))
  {
    alert("Your Character must be 3 to 15 Character");
    document.getElementById('cat_name').focus();
     return false;
   }

  
    var pattern1 = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern1.test(document.registration.cat_name.value)) 
      {
      alert("Error: Please enter valid name!");
      registration.cat_name.focus();
    return false;
     
      }

var b=document.forms["registration"]["fee"].value;
if(b.value=="")
{
alert("Please Enter the Amount");
document.getElementById('fee').focus();
return false;

}
 return true;
}
</script>
</head>



<body>

 
<div class="full">
<form class="box" form action="" method="post" name="registration" onsubmit="return formValidation()" >
  


<input type="text"  id="cat_name" name="cat_name" placeholder="Add Catogory" > <br>
<input type="number" id="fee" name="fee" placeholder="Add Amount" > <br>

<input type="submit" name="submit" value="ADD" ><br>
 
 
</form>
</div>

<!--  <?php
include 'footer.html';
?> -->


<?php


if(isset($_POST['submit']))
{ 
  


    $cat_name = $_POST['cat_name'];
    $ss=mysqli_query($con,"select * from cat where cat_name='$cat_name'");
  $i=mysqli_num_rows($ss);
  if($i>0)
  {
         echo "
        <script>
        alert('This Catogory already exists');
        </script>";
  }
  else
  {
     $sql = "INSERT INTO `cat`(`cat_name`,`fee`) VALUES ('$cat_name','$fee')";
     if(mysqli_query($con, $sql)) {
  
         }
else{
    echo "Error: " . $sql . "" . mysqli_error($con);
            
}}
      

    
    }
?>   


    
<?php 

$sql="select * from `cat`";
 $ch=mysqli_query($con,$sql);
  $no=1;
   ?><br>
<center><h1>Catagory Details</h1></center>
<table  border='1' class="align-center"style=" margin-top: 40px; text-align: center;margin-left: auto;margin-right: auto;border-collapse: collapse;width: 50%;">
  <tr class="align-center" style="color: black;font-size:15px; ">
  <th>Name</th>
  
  <th>Approve</th>
  <th>Reject</th>
  </tr>
  <?php
    while($row=mysqli_fetch_array($ch))
   {
   ?>
   
<tr>
<td class="align-center" >
<?php
echo $row['cat_name'];
?>
</td>




<?php
$app=$row['status'];
 if($app=="0"){
   
 
?>

</td>
<td class="align-center">
<!--<button>APPROVE</button>  <button>REJECT</button>-->
<form action="catadd.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $row['cat_id']; ?>"/>
    <input type="submit" value="ADD" name="submit">
  </form>
</td>

   <?php
   }
   else{
   ?><td><font size="2px" color="green"><b> Added<?php
 } 
 ?>
 <?php
$app1=$row['status'];
 if($app1=="1"){
   
 
?>
<td>
  <form action="catdel.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $row['cat_id']; ?>"/>
    <input type="submit" value="DELETE">
  </form>
  </td>
  <?php
 }
 else{
   
 
 ?><td><font size="2px" color="red"><b>Deleted <?php
 } 
 ?>
</tr>
<?php
$no++;
}
?>
</table>
</center>
</body>
</html>