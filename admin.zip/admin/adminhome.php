<?php
session_start();
include 'co.php';
include 'header.html';
?>



<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="link.css">

</head>





<body>
	




<div class="imgs">
<img src="test.jpg"  width="1400" height="500">
</div>
<h1></h1>




<h2><marquee>
 
</h2></marquee>


<div class="row">
  
</div>


</body>
</html>
<?php
include 'footer.html';
?>