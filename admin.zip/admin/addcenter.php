<?php
include 'co.php';
session_start();
include 'headers.html';
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="reg.css"> 
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" integrity="sha256-7s5uDGW3AHqw6xtJmNNtr+OBRJUlgkNJEo78P4b0yRw= sha512-nNo+yCHEyn0smMxSswnf/OnX6/KwJuZTlNZBjauKhTK0c+zT+q5JOCx0UFhXQ6rJR9jg6Es8gPuD2uZcYDLqSw==" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-latest.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript">
	    function formValidation()
{


  var a=document.forms["registration"]["cen_name"].value;
if(a=="")
{
alert("Please Fill Catogory Field");
document.getElementById('cen_name').focus();
return false;
}
if ((a.length < 3) || (a.length > 30))
  {
    alert("Your Character must be 3 to 15 Character");
    document.getElementById('cen_name').focus();
     return false;
   }

  
    var pattern1 = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern1.test(document.registration.cen_name.value)) 
      {
      alert("Error: Please enter valid name!");
      registration.cen_name.focus();
    return false;
     
      }


var b=document.forms["registration"]["place"].value;
if(b=="")
{
alert("Please Fill Place Field");
document.getElementById('place').focus();
return false;
}
if ((b.length < 3) || (b.length > 30))
  {
    alert("Your Character must be 3 to 15 Character");
    document.getElementById('place').focus();
     return false;
   }

  
    var pattern1 = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern1.test(document.registration.place.value)) 
      {
      alert("Error: Please enter valid name!");
      registration.place.focus();
    return false;
     
      }




 return true;
}
</script>
</head>



<body>
<script></script>
 
<div class="full">
<form class="box" form action="" method="post" name="registration" onsubmit="return formValidation()" >
  


<input type="text" id="cen_name" name="cen_name" placeholder="Enter Center Name" > <br>
<input type="text" id="place" name="place" placeholder="Enter place of Center" > <br>
<input type="text" id="code" name="code" placeholder="Enter  Center code" > <br>
<input type="text" id="seat" name="seat" placeholder="Enter no .of seats" > <br>
<input type="submit" name="submit" value="ADD"><br>
 <!-- <a href="register.php">New user?</a> -->
 
</form>
</div>



<?php


if(isset($_POST['submit']))
{ 
  $cen_name = $_POST['cen_name'];
    $place = $_POST['place'];
    $code = $_POST['code'];
    $seat = $_POST['seat'];
  $ss=mysqli_query($con,"select * from center where cen_name='$cen_name'");
  $i=mysqli_num_rows($ss);
  if($i>0)
  {
         echo "
        <script>
        alert('This Center already exists');
        </script>";
  }
  else
  {



    
     $sql = "INSERT INTO `center`(`cen_name`,`place`,`code`,`seat`) VALUES ('$cen_name','$place','$code','$seat')";


     if(mysqli_query($con, $sql)) {
  
         }
else{
    echo "Error: " . $sql . "" . mysqli_error($con);
            
}}
      

    
    }
?> 

<br><br><center>
<?php 




 $sql="SELECT * FROM `center`";
 $ch=mysqli_query($con,$sql);
  $no=1;
   ?><br>
<center><h1>Center Details</h1></center>
<table  border='1' class="align-center"style=" margin-top: 40px; text-align: center;margin-left: auto;margin-right: auto;border-collapse: collapse;width: 50%;">
  <tr class="align-center" style="color: black;font-size:15px; ">
  <th width="30%" >Center</th>
    <th width="10%">Place</th>
     <th width="10%">Center code</th>
      <th width="10%">No.of Seats</th>
      
  <th>Approve</th>
  <th>Reject</th>
  </tr>
  <?php
    while($row=mysqli_fetch_array($ch))
   {
   ?>
   
<tr>
<td class="align-center" >
<?php
echo $row['cen_name'];
?>
</td>

<td class="align-center">
<?php
echo $row['place'];
?>
</td >
<td class="align-center">
<?php
echo $row['code'];
?>
</td>

<td class="align-center">
<?php
echo $row['seat'];
?>
</td>

<?php
$app=$row['status'];
 if($app=="0"){
   
 
?>

</td>
<td class="align-center">
<!--<button>APPROVE</button>  <button>REJECT</button>-->
<form action="centeradd.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $row['cen_id']; ?>"/>
    <input type="submit" value="ADD" name="submit">
  </form>
</td>

   <?php
   }
   else{
   ?><td><font size="2px" color="green"><b> Added<?php
 } 
 ?>
 <?php
$app1=$row['status'];
 if($app1=="1"){
   
 
?>
<td>
  <form action="centerdel.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $row['cen_id']; ?>"/>
    <input type="submit" value="DELETE">
  </form>
  </td>
  <?php
 }
 else{
   
 
 ?><td><font size="2px" color="red"><b>Deleted <?php
 } 
 ?>
</tr>
<?php
$no++;
}
?>
</table>
</center>
</body>
</html>
