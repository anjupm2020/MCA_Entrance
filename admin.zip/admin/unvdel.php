<?php
include "co.php";

$b=$_POST['id'];
$sql=mysqli_query($con,"UPDATE  unv SET status=0  where uid='$b'");

if ( $sql  ){
  echo  "<script>alert('Removed');
      window.location='addunv.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>