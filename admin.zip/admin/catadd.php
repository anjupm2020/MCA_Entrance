<?php
include "co.php";

$b=$_POST['id'];
$sql=mysqli_query($con,"UPDATE  cat SET status=1  where cat_id='$b'");

if ( $sql  ){
  echo  "<script>alert('added');
      window.location='addcat.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
?>