<?php
include 'co.php';
session_start();

include 'headers.html';

?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="reg.css">


<script type="text/javascript">
        function formValidation()
{


  var a=document.forms["registration"]["catogory"].value;
if(a=="")
{
alert("Please Fill Catogory Field");
document.getElementById('catogory').focus();
return false;
}

var b=document.forms["registration"]["teacher"].value;
if(b=="")
{
alert("Please Fill Catogory Field");
document.getElementById('teacher').focus();
return false;
}








 return true;
}
</script>

</head>



<body>

 
<div class="full">
<form class="box" form action="" method="post" name="registration" onsubmit="return formValidation()">
  


 <?php
    $select="select * from reg,student where reg.loginid=student.loginid";
$res=mysqli_query($con,$select);

     ?>
    <select  name="sname" id="sname"><option>select Catogory</option>
                       <?php
while($row=mysqli_fetch_array($res))
{

?>
<option value="<?php echo $row['name'];?>"><?php echo $row['name'];?></option>
           
<?php
}
?> </select>

<?php
    $select="select * from reg,student where reg.loginid=student.loginid";
$res=mysqli_query($con,$select);
$row=mysqli_fetch_array($res);

     ?>
     <input type="text" name="cen" value="<?php echo $row['center']; ?>">

    <select  name="center" id="center" ><option>select Center</option>
                       <?php
while($row=mysqli_fetch_array($res))
{

?>

<option value="<?php echo $row['center'];?>"><?php echo $row['center'];?></option>
           
<?php
}
?>
 <input type="submit" name="submit" value="ADD">
</form>
</div>
</body>
</html>
<?php
include 'footer.html';
?>


 <?php


if(isset($_POST['submit']))
{ 
  


    $catogory = $_POST['catogory'];
    $teacher = $_POST['teacher'];
     $sql = "INSERT INTO `add_teachers`(`catogory`,`teacher`) VALUES ('$catogory','$teacher')";
     if(mysqli_query($con, $sql)) {
  
         }
else{
    echo "Error: " . $sql . "" . mysqli_error($con);
            
}
      

    
    }
?>  -->