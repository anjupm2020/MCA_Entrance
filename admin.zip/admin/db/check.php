<?php
include('co.php') ;
session_start();
$loginid = $_SESSION['loginid'];
$type = $_SESSION['type'];
$sql = "SELECT * FROM `answers` WHERE cat_id='$type' AND loginid='$loginid'" ;
   $run=mysqli_query($con,$sql);
   $rows=mysqli_fetch_assoc($run);
   if($rows)
{
$_SESSION['msg']= 1;
header('location:selectbox.php');

}
else
{
 header('location:viewquestion.php');
 
}
?>