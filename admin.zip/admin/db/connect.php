<?php
$server = 'localhost';
$user = 'root' ;
$password = '' ;
$db = 'doe';
$cn = new mysqli($server, $user, $password, $db); 
if($cn->connect_error) {
	die("connection failed:" . $cn->connect_error);
}
?>