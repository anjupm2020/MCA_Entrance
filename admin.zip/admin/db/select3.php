
<?php
include 'co.php';
session_start();

$loginid = $_SESSION['loginid'];
?>

 <!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		input[type=submit] {
  background-color:green ;
  color: white;
  padding: 12px 20px;
  margin-left:10px;
  float: center;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  width:50%;
}
	</style>
</head>
<body>
<?php
$sql = "SELECT * FROM `student` where loginid='$loginid'" ;
$run=mysqli_query($con,$sql);
while($rows=mysqli_fetch_array($run))
{
$type=$rows['cat_id'];
if($type==1)?>
<center>
<?php
$select="SELECT * FROM `quiz`";
$res=mysqli_query($con,$select);
?><br><br><br>
<table border="1" width="75%" align="center" bgcolor="yellow">
	<th>Exam</th>
	<th>Correct</th>
	<th>Wrong</th>
	<th>Total</th>
	<th>Action</th>



<?php
while($row=mysqli_fetch_array($res))
{

?>
<tr>
<td align="center"><?php echo $row['cat_id'];?></td>
<td align="center"><?php echo $row['correct'];?></td>
<td align="center"><?php echo $row['wrong'];?></td>
<td align="center"><?php echo $row['total'];?></td>
<td align="center">
	
<form action="" method="post">
	<input type="submit" name="submit" value="Start">
</form>

</td>

</tr>
<?php
}
?>
</table></center>

<?php
}
?>

</body>
</html>


<?php
if (isset($_POST['submit'])) {
	$q=mysqli_query($con,"INSERT INTO history set loginid='$loginid'") or die('Error');

    $sql= mysqli_query($con,"UPDATE answers set  userans=0") or die('Error');  
    if($sql)
    {
    	header('Location:selectbox.php');
    }
}
?>





