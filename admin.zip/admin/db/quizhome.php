<?php
include 'co.php';
session_start();
$loginid = $_SESSION['loginid'];
$sql = "SELECT * FROM `reg` WHERE loginid='$loginid'" ;
$run=mysqli_query($con,$sql);
if (mysqli_num_rows($run)==0)
{
echo 'you are not registered for any event';
}
else
{
$_SESSION['q']=1;
?>
<?php
$select="SELECT * FROM `student` where loginid='$loginid'";
$res=mysqli_query($con,$select);
while($row=mysqli_fetch_array($res))
{
	$_SESSION['type']=$row['cat_id'];
}

$type=$_SESSION['type'];
header('location:showexam.php');
}
?>