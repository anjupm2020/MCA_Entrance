
<?php
include 'co.php';
session_start();

$loginid = $_SESSION['loginid'];
?>

 <!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		input[type=submit] {
  background-color:green ;
  color: white;
  padding: 12px 20px;
  margin-left:10px;
  float: center;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  width:50%;
}
	</style>
</head>
<body>
<?php
$sql = "SELECT * FROM `student`,`reg`,`login` WHERE loginid='$loginid'" ;
$run=mysqli_query($con,$sql);
while($rows=mysqli_fetch_array($run))
{
$type=$rows['cat_id'];
if($type==1)?>
<center>
<?php
$select="SELECT * FROM `quiz`";
$res=mysqli_query($con,$select);
?><br><br><br>
<table border="1" width="75%" align="center" bgcolor="yellow">
	<th>Exam</th>
	<th>Correct</th>
	<th>Wrong</th>
	<th>Total</th>
	<th>Action</th>



<?php
while($row=mysqli_fetch_array($res))
{

?>
<tr>
<td align="center"><?php echo $row['name'];?></td>
<td align="center"><?php echo $row['username'];?></td>
<td align="center"><?php echo $row['center'];?></td>
<td align="center"><?php echo $row['unv'];?></td>
<td align="center">
	
<form action="" method="post">
	<input type="submit" name="submit" value="Start">
</form>

</td>

</tr>
<?php
}
?>
</table></center>

<?php
}
?>

</body>
</html>






