
<?php
include 'co.php';
session_start();
$sql = "SELECT * FROM `question` where cat id=2" ;
$run=mysqli_query($con,$sql);
while($rows=mysqli_fetch_array($run))

$qno=$rows['qno'];


?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php

 	
       
   


$select="SELECT distinct * FROM `question` where cat_id=2 and qno='$qno'  limit 1 ";
$res=mysqli_query($con,$select);

?>

<?php
while($row=mysqli_fetch_array($res))
{

?>
<form method="POST" action="">
<?php
$qno=$row['qno'];

 // echo $row['qno'];?> 
<?php echo $row['qn'];?> <br>
<input type="radio" value="<?php echo $row['o1'];?>" ><?php echo $row['o1'];?><br>
<input type="radio" value="<?php echo $row['o2'];?>" ><?php echo $row['o2'];?><br>
<input type="radio" value="<?php echo $row['o3'];?>" ><?php echo $row['o3'];?><br>
<input type="radio" value="<?php echo $row['o4'];?>" ><?php echo $row['o4'];?><br>

<input type="submit" name="submit" value="next">
</form>

</table></center>
</body>
</html>
<?php
if (isset($_POST['submit'])) {
$sql = "SELECT * FROM `question` where cat_id=2" ;
$run=mysqli_query($con,$sql);
while($rows=mysqli_fetch_array($run))
$qno=$rows['qno'];

}

$qno++;
}
?>

