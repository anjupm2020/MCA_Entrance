<?php
include('co.php') ;
session_start();

$qq = $_SESSION['q'];

$type = $_SESSION['type'];

$sql = "SELECT DISTINCT  * FROM `question` WHERE cat_id='$type'  " ;
$result = mysqli_query($con, $sql);
$row=mysqli_fetch_assoc($result); 
 if(is_array($row))
   {
   $_SESSION["qno"] = $row['qno'];

  // /header("location: home.php");
  $qno=$_SESSION['qno'];
            ?>
            <form action=" " method="post">
              <?php  $qno=$row['qno'];  ?>
            <?php echo  $row["qno"]; ?> <?php echo $row["qn"];?> <br />
            <input type="radio" name="userans"  value="<?php echo $row["o1"];?>"> <?php echo $row["o1"];?>  
            
            <input type="radio" name="userans"   value="<?php echo $row["o1"];?>"> <?php echo $row["o2"];?> <br />

            <input type="radio" name="userans"   value="<?php echo $row["o1"];?>"> <?php echo $row["o3"];?>

            <input type="radio" name="userans"  value="<?php echo $row["o1"];?>"> <?php echo $row["o4"];?> <br /><br />
             <button value="submit" name="click">Next</button>
             <?php
           if(isset($_POST['click'])) 
             { 
   //            $userselected = $_POST['userans'];
   //  $fetchqry2 = "UPDATE `answers` SET `userans`='$userselected' WHERE cat_id='$type' and qno='qno'";
   //  $result2 = mysqli_query($con,$fetchqry2);
   //  if ($result2) {
   // @$_SESSION['qno'] +=$_SESSION['type'] ;
   //   }
              
              
              @$_SESSION['q']++;


    }
   ?> 
            </form>
         <?php
         
                    }
          else {
                // header('location:test_result.php');
               }
?>
<html>
</html>
