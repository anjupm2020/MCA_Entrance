<?php
include "co.php";
session_start() ;
$type=$_SESSION['type'];
$loginid = $_SESSION['loginid'];
extract($_POST);

$q=mysqli_query($con,"INSERT INTO history set loginid='$loginid'") or die('Error');
       if($q)
       {
        header('Location:showqns.php');
       }
?>