<?php
	$con= new mysqli('localhost','root','','quizzer')or die("Could not connect to mysql".mysqli_error($con));
?>