<?php
include('co.php') ;

session_start();
$loginid = $_SESSION['loginid'];
extract($_POST);
$_SESSION['type']=$type;

header('location:showqns.php');
?>

