
<?php
include 'co.php';
session_start();
$login=$_SESSION['login'];
// $type=$_SESSION['type'];
// $usr_name=$_SESSION['uname'];
// $id=$_SESSION['logid'];
if($login)
{
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Add Place</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" 
integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" 
crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" 
integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
 crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
 integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
 crossorigin="anonymous"></script>



<!--<style>
.frm{
	align:center;
	top:10%;
	left:10%;
	width:45%;
	height:60%;
	margin-left:30px;
	padding:10px;
}

body
    {
		background-image:url("f.jpg");
	 margin: 0;
    font-family: Arial, Helvetica, sans-serif;
    }
	
	* {
    box-sizing: border-box;
}

input[type=text],input[type=text],input[type=select],input[type=date],input[type=text],input[type=text],input[type=text],[type=password],[type=password],input[type=textarea] {
   
    padding: 12px 22px;
    border: 1px solid #ccc;
    border-radius: 4px;
    resize: vertical;
	width:20%;
}
 select {
        width: 20px;
        height: 30px;
    }
    select:focus {
        min-width: 20px;
        width: auto;
    }    

label {
padding: 10px 10px 10px 0;
    display: inline-block;
}

input[type=submit] {
    background-color: #4CAF50;
    color: white;
    padding: 12px 12px;
    
	margin-border: none;
    border-radius: 8px;
	width:70%;   
}

.col-251 {
    float: left;
    width: 45%;
    margin-top: 3px;
}
.col-751 {
    float: left;
    width: 98%;
   
}
.row1:after {
    content: "";
    display: table;
    clear: both;
}
@media screen and (max-width: 600px) {
    .col-251, .col-751, input[type=submit],input[type=button] {
        width: 100%;
        margin-top: 0;
    }

    }
}



.</style>-->


</head>
<body>	
<div class="page-container">	
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->
				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									 <a href="index.html"> <h1>Volare Airways</h1> 
									<!--<img id="logo" src="" alt="Logo"/>--> 
								  </a> 								
							</div>																						
						 </div>
						 <div class="header-right">
							
							<!--notification menu end -->
							<div class="profile_details">		
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">	
												<span class="prfil-img"><img src="images/p1.png" alt=""> </span> 
												<div class="user-name">
													<p></p>
													<span> </span>
												</div>
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>	
											</div>	
										</a>
										<ul class="dropdown-menu drp-mnu">
											
											<!--<li> <a href="#"><i class="fa fa-user"></i> Profile</a> </li> -->
											<li> <a href="/project/logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
										</ul>
									</li>
								</ul>
							</div>					
						</div>
				     <div class="clearfix"> </div>	
				</div>
				
				
					
					


 <h2><center></center></h2><br>
<div class="inner-block1"><br></div>
<div class="container-fluid ">
<div class="row">
  
		<div class="col-md-4 col-sm-4 col-xs-12 "></div>
		<div class="col-md-4 col-sm-4 col-xs-12  box">
			
				<form name="myform" method="post" class="form-container">
					
					<br>
					<h2 ><center>Add places</center> </h2><br>
						<div class="form-group">
						<label>Place Name *</label>
						<input id="placename1" name="placename1" class="form-control" type="textarea" data-validation="required" rows="5" cols="5">
						<span id="error_notice" class="text-danger"></span>
					</div><br>
					<center><button id="submit" type="submit" name="submit" value="Add Notice" class="btn btn-success center">Add Place</button></center>


			
				</form>

			</div>
			
			<div class="col-md-4 col-sm-4 col-xs-12"></div>
		</div >
	</div>
 

  </form>

</font>
 
 


<!--inner block end here-->
<!--pop-up-grid-->
				               <div id="popup">
								<div id="small-dialog" class="mfp-hide">
									  <!-- <div class="pop_up">
									 	<div class="payment-online-form-left">
											<form>
												<h4><span class="shoppong-pay-1"> </span>Shipping Details</h4>
												<ul>
													<li><input class="text-box-dark" type="text" value="First Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'First Name';}"></li>
													<li><input class="text-box-dark" type="text" value="Last Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Last Name';}"></li>
												</ul>
												<ul>
													<li><input class="text-box-dark" type="text" value="Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}"></li>
													<li><input class="text-box-dark" type="text" value="Phone" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Phone';}"></li>
												</ul>
												<ul>
													<li><input class="text-box-dark" type="text" value="Address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Address';}"></li>
													<li><input class="text-box-dark" type="text" value="Pin Code" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Pin Code';}"></li>
													
												</ul>
												<div class="clear"></div>
												<h4 class="paymenthead"><span class="payment"></span>Payment Details</h4>
												<div class="clear"></div>										
												<ul>
													<li><input class="text-box-dark" type="text" value="Card Number" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Card Number';}"></li>
													<li><input class="text-box-dark" type="text" value="Name on card" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name on card';}"></li>
												
												</ul>
												<ul>
													<li><input class="text-box-light hasDatepicker" type="text" id="datepicker" value="Expiration Date" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Expiration Date';}"><em class="pay-date"> </em></li>
													<li><input class="text-box-dark" type="text" value="Security Code" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Security Code';}"></li>
												
												</ul>
												<ul class="payment-sendbtns">
													<li><input type="reset" value="Reset"></li>
													<li><a href="#" class="order">Process order</a></li>
												</ul>
												<div class="clear"></div>
											</form>
										</div>
						  			</div>-->
								</div>
								</div><br><br><br><br><br><br><br><br><br><br>
								
<!--pop-up-grid-->
<!--copy rights start here-->
	
<!--COPY rights end here-->
</div>
</div>
<!--slider menu-->
       <div class="sidebar-menu">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
			      <!--<img id="logo" src="" alt="Logo"/>--> 
			  </a> </div>		  
		    <div class="menu">
		      <ul id="menu" >
		        <li id="menu-home" ><a href="/project/adminhome.php"><i class="fa fa-tachometer"></i><span>Home</span></a></li>
		        <li><a href="#"><i class="fa fa-cogs"></i><span>Add</span><span class="fa fa-angle-right" style="float: right"></span></a>
		          <ul>
		            <li><a href="/project/login/signup/dash1/addfdetails.php">Flight Schedules</a></li>
		           	 <li><a href="/project/login/signup/dash1/addspecialoffers.php">Special Offers</a></li>
					<li><a href="/project/login/signup/dash1/adminadd.php">Add-On Services</a></li>	
		            <li><a href="/project/login/signup/dash1/addplace.php">Places</a></li>
				   <li><a href="/project/login/signup/dash1/notice1.php">Notice</a></li>
				  </ul>
		        </li>
		        <li id="menu-comunicacao" ><a href="#"><i class="fa fa-book nav_icon"></i><span>View</span><span class="fa fa-angle-right" style="float: right"></span></a>
		         <ul id="menu-comunicacao-sub" >
		            <li id="menu-mensagens" style="width: 120px" ><a href="/project/login/signup/dash1/view.php">Flight Schedules</a>		              
		            </li>
					<li id="menu-arquivos" ><a href="/project/login/signup/dash1/viewadd.php">Add-On Services</a></li>
					<li id="menu-arquivos" ><a href="/project/login/signup/dash1/viewpackages.php">Special Offers</a></li>
		            <li id="menu-arquivos" ><a href="/project/login/signup/dash1/viewbook.php">Bookings</a></li>
		             <li id="menu-arquivos" ><a href="/project/login/signup/dash1/viewfeed.php">feedbacks</a></li>
					  <li id="menu-arquivos" ><a href="/project/login/signup/dash1/viewnotice.php">Notice</a></li>
		          </ul>
		        </li>
		        
		        <li id="menu-academico" ><a href="#"><i class="fa fa-file-text"></i><span>History</span><span class="fa fa-angle-right" style="float: right"></span></a>
		         <ul id="menu-academico-sub" >
		          	 
		            <li id="menu-academico-avaliacoes" ><a href="/project/login/signup/dash1/viewflighthistory.php">Flight Schedules</a></li>
					 <li id="menu-academico-avaliacoes" ><a href="/project/login/signup/dash1/viewpackageshistory.php" class="drop-text">Special Offers</a></li>
					   <li id="menu-academico-avaliacoes" ><a href="/project/login/signup/dash1/viewplacehistory.php">Places</a></li>
					  <li id="menu-academico-avaliacoes" ><a href="/project/login/signup/dash1/viewaddhistory.php">Add-On Services</a></li>	
					   <li id="menu-academico-avaliacoes" ><a href="/project/login/signup/dash1/viewnotice.php">Notices</a></li>	           
		          </ul>
		        </li>
		        
		        
		        <li><a href="#"><i class="fa fa-envelope"></i><span>Edit</span><span class="fa fa-angle-right" style="float: right"></span></a>
		        	<ul id="menu-academico-sub" >
			            <li id="menu-academico-avaliacoes" ><a href="/project/login/signup/dash1/editflight.php">Flight Schedules</a></li>
						<li id="menu-academico-boletim" ><a href="/project/login/signup/dash1/editadd.php">Add-On Services</a></li>
						<li id="menu-academico-boletim" ><a href="/project/login/signup/dash1/editpackages.php">Special Offers</a></li>
						<li id="menu-academico-boletim" ><a href="/project/login/signup/dash1/editplaces.php">Places</a></li>
			            <li id="menu-academico-boletim" ><a href="/project/login/signup/dash1/editnotice.php">Notice</a></li>
		             </ul>
		        </li>
		         <!--<li><a href="#"><i class="fa fa-cog"></i><span>Settings</span><span class="fa fa-angle-right" style="float: right"></span></a>
		         	 <ul id="menu-academico-sub" >
			            <li id="menu-academico-avaliacoes" ><a href="changeadmin.php">Change Admin</a></li>
			               <li id="menu-academico-avaliacoes" ><a href="viewadmin.php">View Admin</a></li>
		             </ul>
		         </li>-->
		        <!-- <li><a href="#"><i class="fa fa-shopping-cart"></i><span>E-Commerce</span><span class="fa fa-angle-right" style="float: right"></span></a>
		         	<ul id="menu-academico-sub" >
			            <li id="menu-academico-avaliacoes" ><a href="product.html"></a></li>
			            <li id="menu-academico-boletim" ><a href="price.html">Price</a></li>
		             </ul>
		         </li>-->
				   <li id="menu-home" ><a href=""><i class="fa fa-tachometer"></i><span>Logout</span></a></li>
		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>
</div>
<!--slide bar menu end here-->
<script>
var toggle = true;
            
$(".sidebar-icon").click(function() {                
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }               
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->

<!--<div class="copyrights">
	 <p>© 2019 volareairways. All Rights Reserved | Design by  <a href="http://volareairways.com/" target="_blank">volare Airways</a> </p>
</div>-->

<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- Calendar -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/3.3.1/jquery-ui.min.js" ></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script>
		jQuery.validator.addMethod("noSpace", function(value, element) {
    return value == '' || value.trim().length != 0;
}, "No space please and don't leave it empty");




jQuery.validator.addMethod("alphabetsnspace", function(value, element) {
    return this.optional(element) || /^[a-zA-Z ]*$/.test(value);},"Invalid!");



$.validator.addMethod( "alphanumeric", function( value, element ) {
return this.optional( element ) || /^\w+$/i.test( value );
}, "Letters, and underscores only please" );

var $registrationForm = $('#register');
if($registrationForm.length){
  $registrationForm.validate({
      rules:{
          //username is the name of the textbox
          placename1: {
              required: true,
              //alphanumeric is the custom method, we defined in the above
              alphabetsnspace: true
          },
        /*lname:{
           required: true

          },*/
         /*lname:{
            required: true,
             alphabetsnspace: true
        },
		
		dob:{
             required: true,
			},
		      
          phno:{
              required:true,
              phoneno: true,
              number:true,
              maxlength:10,
              minlength:10
            },

          email: {
              required: true,
              customEmail: true
          },

          uname: {
              required: true,
              noSpace: true,
              alphanumeric: true
          },

          pwd: {
              required: true,
              passstrength: true,
              minlength:8
          },
          cpwd: {
              required: true,
              equalTo: '#pwd'
          },*/
          
      },
      messages:{
          placename1: {
              //error message for the required field
              required: 'Enter Firstname',
              alphabetsnspace: 'FirstName must be in character'
          },
        /* lname:{
            required: 'Please enter the lname!'
         },*/
         /* lname:{
            required: 'Enter Lastname',
			 alphabetsnspace: 'LastName must be in character'
          },
		   dob:{
            required: 'Enter a valid date'
             },
		  
          phno:{
            required: 'Enter phno:',
            number: 'Invalid format',
            minlength: 'Invalid',
            maxlength: 'Invalid'
          },
          email: {
              required: 'enter email',
              //error message for the email field
              email: 'Enter valid email!'
          },
          uname: {
              //error message for the required field
              required: 'Enter username'
          },
          
          pwd: {
              required: 'Enter password',
              passstrength: 'Weak password',
              minlength:'Too short'
          },
          cpwd: {
              required: 'Re-enter password',
              passstrength: 'Weak password',
              minlength:'Too short',
              equalTo: 'Enter same password'
          },*/

      },

  });
}
</script>

</body>
</html>

<?php
if(isset($_POST['submit']))
{
	$placename1=$_POST['placename1'];
	
	
	
	
	//$sq1="insert into flightdescription(description,status)values('$description',1)";
	//$sq1="INSERT INTO `flightdescription`( `description`, `status`) VALUES ('$description',1)";
	//  $ch1=mysqli_query($con,$sq1);
	  // if($ch1)
{?>
	 <script>
//alert("Flight Details Added Successfully");
 // header("location: admin.php");
 
</script>
	<?php
}
//else
//{
 // echo"error:".$sql."<br>".mysqli_error($con);
//}
	
   $sq="insert into placename1(placename1,status)values('$placename1',1)";
   $ch=mysqli_query($con,$sq);
  if($ch)
{?>
	 <script>
alert("Notice Added Successfully");
  header("location: addplace.php");
 
</script>
	<?php
}
else
{
  echo"error:".$sq."<br>".mysqli_error($con);
}
}

mysqli_close($con);
	
	
?>
<?php
}
else
header("location:l/project/login/l.php");
?>

                      
						
