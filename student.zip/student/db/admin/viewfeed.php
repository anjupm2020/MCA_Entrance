<?php
include 'acd.php';
session_start();
$login=$_SESSION['login'];
$type=$_SESSION['type'];
$usr_name=$_SESSION['uname'];
$id=$_SESSION['logid'];
if($login)
{
?>
<html>
<head>
<title>view feedback</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<!--//skycons-icons-->
</head>
<body>	
<div class="page-container">	
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->
				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									 <a href="index.html"> <h1>Volare Airways</h1> 
									<!--<img id="logo" src="" alt="Logo"/>--> 
								  </a> 								
							</div>
							<!--search-box-->
								<!--<div class="search-box">
									<form>
										<input type="text" placeholder="Search..." required="">	
										<input type="submit" value="">					
									</form>
								</div>--><!--//end-search-box-->
							<div class="clearfix"> </div>
						 </div>
						 <div class="header-right">
							<div class="profile_details_left"><!--notifications of menu start -->
								
								<div class="clearfix"> </div>
							</div>
							<!--notification menu end -->
							<div class="profile_details">		
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">	
												<span class="prfil-img"><img src="images/p1.png" alt=""> </span> 
												<div class="user-name">
													<p></p>
													<span><?php 
  $sql1=mysqli_query($con,"SELECT `uname` FROM `login` WHERE  logid='$id'");
				if($row1=mysqli_fetch_array($sql1))
				$usr_name=$row1['uname'];
				$_SESSION['uname']=$usr_name;
				
  
  echo "$usr_name";
  ?></span>
												</div>
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>	
											</div>	
										</a>
										<ul class="dropdown-menu drp-mnu">
											<!--<li> <a href="#"><i class="fa fa-cog"></i> Settings</a> </li> -->
											<!--<li> <a href="#"><i class="fa fa-user"></i> Profile</a> </li> -->
											<li> <a href="/project/logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
										</ul>
									</li>
								</ul>
							</div>
										
						</div>
				     <div class="clearfix"> </div>	
				</div>
				
				
				
<!--heder end here-->
<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>
		<!-- /script-for sticky-nav -->
<!--inner block start here-->
<!--<div class="inner-block"></div>-->
<br><br><br><br><br><br>
  <div class="blank">
    	<center><h1>Feedbacks</h1></center>

 <!--$sql = "INSERT INTO `center`(`cen_name`,`place`) VALUES ('$cen_name','$place')";
     if(mysqli_query($con, $sql)) {
  
         }
		 ?> -->
<br><center>
<?php
$select="select * from feedback where status=1";
$res=mysqli_query($con,$select);
?>
<table border="1"  width="75%" >

<tr>
<th>&nbsp<center>Flight Name</center>&nbsp</th>

<th>&nbsp<center>Flight Name</center&nbsp></th>
<th>&nbsp<center>Feedback</center>&nbsp</th>
<th>&nbsp<center>Date</center>&nbsp</th>
<!--<th width="10%"><center>Ending Point</center></th>
<th width="10%"><center>Date  </center></th>
<th width="10%"><center> Time  </center></th>
<th width="10%"><center>Total Business Seats </center></th>
<th width="10%"><center>Total Economic Seats </center></th>
<th width="10%"><center>Total Window Seats </center></th>
<th width="10%"><center> Amount For Adults </center></th>
<th width="10%"><center> Amount For Child </center></th>
<th width="10%"><center>Amount For Infant </center></th>-->
<!--<th colspan="2"><center> Actions</center></th>-->
</tr>
<?php
while($row=mysqli_fetch_array($res))
{

?>

<tr>
<td><center><?php echo $row['feedid'];?></center></td>
<td><center><?php echo $row['flname'];?></center></td>
<td><center><?php echo $row['feedback'];?></center></td>
<td><center><?php echo $row['feeddate'];?></center></td>
<!--<td><?php echo $row['time'];?></td>
<td><?php echo $row['bseat'];?></td>
<td><?php echo $row['eseat'];?></td>
<td><?php echo $row['wseat'];?></td>
<td><?php echo $row['adultamt'];?></td>
<td><?php echo $row['childamt'];?></td>
<td><?php echo $row['infantamt'];?></td>-->
</td>
<!--<td width="10%"><center>
  <form action="deletenotice.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $row['nid']; ?>"/>
    <input type="submit" value="Delete">
  </form></center>
  </td>
  
  <td width="10%"><center>
<form action="update.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $row['nid']; ?>"/>
    <input type="submit" value="Update">
  </form></center>
  </td>-->
</tr>
<?php
}
?>
</table><br>
<br>

</html>
</body>
    </div>


</div>
</div>
<!--slider menu-->
    <div class="sidebar-menu">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
			      <!--<img id="logo" src="" alt="Logo"/>--> 
			  </a> </div>		  
		    <div class="menu">
		      <ul id="menu" >
		        <li id="menu-home" ><a href="/project/adminhome.php"><i class="fa fa-tachometer"></i><span>Home</span></a></li>
		        <li><a href="#"><i class="fa fa-cogs"></i><span>Add</span><span class="fa fa-angle-right" style="float: right"></span></a>
		          <ul>
		            <li><a href="/project/login/signup/dash1/addfdetails.php">Flight Schedules</a></li>
		           	 <li><a href="/project/login/signup/dash1/addspecialoffers.php">Special Offers</a></li>
					<li><a href="/project/login/signup/dash1/adminadd.php">Add-On Services</a></li>	
		            <li><a href="/project/login/signup/dash1/addplace.php">Places</a></li>
				   <li><a href="/project/login/signup/dash1/notice1.php">Notice</a></li>
				  </ul>
		        </li>
		        <li id="menu-comunicacao" ><a href="#"><i class="fa fa-book nav_icon"></i><span>View</span><span class="fa fa-angle-right" style="float: right"></span></a>
		         <ul id="menu-comunicacao-sub" >
		            <li id="menu-mensagens" style="width: 120px" ><a href="/project/login/signup/dash1/view.php">Flight Schedules</a>		              
		            </li>
					<li id="menu-arquivos" ><a href="/project/login/signup/dash1/viewadd.php">Add-On Services</a></li>
					<li id="menu-arquivos" ><a href="/project/login/signup/dash1/viewpackages.php">Special Offers</a></li>
		            <li id="menu-arquivos" ><a href="/project/login/signup/dash1/viewbook.php">Bookings</a></li>
		             <li id="menu-arquivos" ><a href="/project/login/signup/dash1/viewfeed.php">feedbacks</a></li>
					  <li id="menu-arquivos" ><a href="/project/login/signup/dash1/viewnotice.php">Notice</a></li>
		          </ul>
		        </li>
		        
		        <li id="menu-academico" ><a href="#"><i class="fa fa-file-text"></i><span>History</span><span class="fa fa-angle-right" style="float: right"></span></a>
		         <ul id="menu-academico-sub" >
		          	 
		            <li id="menu-academico-avaliacoes" ><a href="/project/login/signup/dash1/viewflighthistory.php">Flight Schedules</a></li>
					 <li id="menu-academico-avaliacoes" ><a href="/project/login/signup/dash1/viewpackageshistory.php" class="drop-text">Special Offers</a></li>
					   <li id="menu-academico-avaliacoes" ><a href="/project/login/signup/dash1/viewplacehistory.php">Places</a></li>
					  <li id="menu-academico-avaliacoes" ><a href="/project/login/signup/dash1/viewaddhistory.php">Add-On Services</a></li>	
					   <li id="menu-academico-avaliacoes" ><a href="/project/login/signup/dash1/viewnotice.php">Notices</a></li>	           
		          </ul>
		        </li>
		        
		        
		        <li><a href="#"><i class="fa fa-envelope"></i><span>Edit</span><span class="fa fa-angle-right" style="float: right"></span></a>
		        	<ul id="menu-academico-sub" >
			            <li id="menu-academico-avaliacoes" ><a href="/project/login/signup/dash1/editflight.php">Flight Schedules</a></li>
						<li id="menu-academico-boletim" ><a href="/project/login/signup/dash1/editadd.php">Add-On Services</a></li>
						<li id="menu-academico-boletim" ><a href="/project/login/signup/dash1/editpackages.php">Special Offers</a></li>
						<li id="menu-academico-boletim" ><a href="/project/login/signup/dash1/editplaces.php">Places</a></li>
			            <li id="menu-academico-boletim" ><a href="/project/login/signup/dash1/editnotice.php">Notice</a></li>
		             </ul>
		        </li>
		         <!--<li><a href="#"><i class="fa fa-cog"></i><span>Settings</span><span class="fa fa-angle-right" style="float: right"></span></a>
		         	 <ul id="menu-academico-sub" >
			            <li id="menu-academico-avaliacoes" ><a href="changeadmin.php">Change Admin</a></li>
			               <li id="menu-academico-avaliacoes" ><a href="viewadmin.php">View Admin</a></li>
		             </ul>
		         </li>-->
		        <!-- <li><a href="#"><i class="fa fa-shopping-cart"></i><span>E-Commerce</span><span class="fa fa-angle-right" style="float: right"></span></a>
		         	<ul id="menu-academico-sub" >
			            <li id="menu-academico-avaliacoes" ><a href="product.html"></a></li>
			            <li id="menu-academico-boletim" ><a href="price.html">Price</a></li>
		             </ul>
		         </li>-->
				   <li id="menu-home" ><a href="/project/logout.php"><i class="fa fa-tachometer"></i><span>Logout</span></a></li>
		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>
</div>
<!--slide bar menu end here-->
<script>
var toggle = true;
            
$(".sidebar-icon").click(function() {                
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }               
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="js/jquery.nicescroll.js"></script>
		<script src="js/scripts.js"></script>
		<!--//scrolling js-->
<script src="js/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
</html>

<?php
}
 else
header("location:/project/login/l.php");
?>
                      
						
