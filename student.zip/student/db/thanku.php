<?php
include 'co.php';
include 'uheader.html';
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
	.thank{
		margin-top:200px;
		margin-left:350px;
		color:red;
	}	
	</style>
</head>
<body>
<div class="thank">
	<h1>Thank You For Your Participation And Support</h1>
</div>
</body>
</html>
<?php
include 'footer.html'
?>