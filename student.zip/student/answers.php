
<?php
include 'co.php';
session_start();
$loginid=$_SESSION['loginid'];

?>

<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<h1>Answers</h1>
<center> <br><br><br>
<?php
$select="SELECT question.qn,question.qno,answers.qno,answers.ans,answers.userans FROM `question`,`answers` where question.qno=answers.qno and answers.loginid='$loginid'";
$res=mysqli_query($con,$select);
?>
<table  width="65%">
    <th>Question No</th>
    <th>Question</th>
    <th>Answer</th>
    <th>Your Answer</th>

<?php
while($row=mysqli_fetch_array($res))
{

?>
<tr>
<td ><?php echo $row['qno'];?></td>
<td><?php echo $row['qn'];?></td>
<td style="background-color:lightgreen;"><?php echo $row['ans'];?></td>
<td style="background-color:pink;"><?php echo $row['userans'];?></td>
</tr>
<?php
}
?>
</table></center>
</body>
</html>