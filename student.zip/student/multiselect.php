

<?php
session_start();
include 'co.php';

?>


<!DOCTYPE html>
<html>
 <head>
  <title></title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />
  <style type="text/css">
    input[type=text],[type=password],select
    {
     width:30%;
    }
  </style>
 </head>
 <body bgcolor="pink">
  <br /><br />
  <div class="container" style="width:600px;">
   <h2 align="center"></h2>
   <br /><br />
   <form method="post" id="framework_form" action=" ">



    <input type="text" name="name" id="name" placeholder="name"><br><br>
    <input type="date" name="dob" id="dob" placeholder="name"><br><br>
    <input type="text" name="email" id="name" placeholder="email"><br><br>
    <input type="text" name="mobile" id="mobile" placeholder="mobile"><br><br>
    <input type="text" name="uname" id="uname" placeholder="username"><br><br>
    <input type="password" name="pass" id="pass" placeholder="password"><br><br>
    <input type="password" name="cpass" id="cpass" placeholder="confirm"><br><br>
    
    <div class="form-group">
     
     <?php
    $select="select * from cat";
    $res=mysqli_query($con,$select);
    ?>
     <select id="cat_id" name="cat_id[]" multiple class="form-control" >
      <?php
                   while($row=mysqli_fetch_array($res))
                      {

                        ?>
                      <option value="<?php echo $row['cat_name'];?>"><?php echo $row['cat_name'];?></option>
           
                      <?php
                      }
   ?>
     </select>
    </div>

    <?php
    $select="select * from course";
    $res=mysqli_query($con,$select);
    ?>
    <select  name="elig" id="elig"  ><option value="">select your Eligibility</option>
                 <?php
                   while($row=mysqli_fetch_array($res))
                      {

                        ?>
                      <option value="<?php echo $row['cid'];?>"><?php echo $row['cname'];?></option>
           
                      <?php
                      }
   ?></select><br>


         <?php
    $select="select * from center";
     $res=mysqli_query($con,$select);

     ?>
    <select  name="center"  id="center">
      <option value="">select your Exam center</option>
                       <?php
     while($row=mysqli_fetch_array($res))
   {

   ?>
       <option value="<?php echo $row['cen_name'];?>"><?php echo $row['cen_name'];?></option>
           
    <?php
    }
      ?></select>
<br><br><br>
    <div class="form-group">
     <input type="submit" class="btn btn-info" name="submit" value="Submit" />
    </div>
   </form>
   <br />
  </div>
 </body>
</html>

<script>
$(document).ready(function(){
 $('#cat_id').multiselect({
  nonSelectedText: 'Select Exams',
  enableFiltering: true,
  enableCaseInsensitiveFiltering: true,
  buttonWidth:'270px'
 });
 });
</script>





<?php

 if(isset($_POST['submit']))
  {
     $name = $_POST['name'];
     $uname= $_POST['uname'];
     $pass = $_POST['pass'];
     $mobile = $_POST['mobile']; 
     $email = $_POST['email'];
     $dob=$_POST['dob'];
     $elig = $_POST['elig'];
     $center = $_POST['center'];
     
       $ps=md5($pass);

$str="insert into login set uname='$uname',pass='$ps',type='S'";
       if((mysqli_query($con,$str)))  {
      
      
         } 

$result = mysqli_query($con,"SELECT * FROM `login` WHERE uname='$uname' and pass ='$ps'");
   $row  = mysqli_fetch_array($result);
   if(is_array($row))
   {
   $_SESSION["loginid"] = $row['loginid'];

  // /
  } 
   else 
   {

   }

 $loginid = $_SESSION['loginid'];


        $sql="insert into reg set loginid='$loginid',name='$name',email='$email',mobile='$mobile'";
     
       if((mysqli_query($con,$sql))) 
        {
      
      
        }


  
if(isset($_POST["cat_id"]))
{
 $cat_id = '';
 foreach($_POST["cat_id"] as $row)
 {
  $cat_id .= $row . ', ';
 }
 $cat_id = substr($cat_id, 0, -2);
 // $query = "INSERT INTO student(cat_id) VALUES('".$cat_id."')";
 // if(mysqli_query($con, $query))
 // {
  
 // }

           
      
       
$sq="insert into student set loginid='$loginid',dob='$dob',elig='$elig',center='$center',cat_id='$cat_id'";
     
       if((mysqli_query($con,$sq))) 
        {
        
    
        }

      }
 
    header('Location:book.php');
     }
 
?>