function formValidation()
{


     var a = document.registration.dob.value;
     var b = document.registration.elig.value;
     
     var c = document.registration.unv.value;
     


if(a=="")
{
alert("Please Enter Your dob");
a.focus();
return false;
}


 if(b=="")
 {
 alert("Please Select your eligibility");
  b.focus();
 return false;
 }


if(c=="")
 {
 alert("Please Select your University");
  c.focus();
 return false;
 }
 return true;

}