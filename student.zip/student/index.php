<?php
session_start();
include 'co.php';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="icon" href="favicon.ico" type="image/icon" sizes="16x16">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="viewport" content="width=device-width, initial-scale=1">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />
<title> Quizzer  </title>
   
 <link rel="stylesheet" href="css/main.css">
 <link  rel="stylesheet" href="css/font.css">
 <script src="js/jquery.js" type="text/javascript"></script>
<link  rel="stylesheet" href="css/bootstrap.min.css"/>
 <link  rel="stylesheet" href="css/bootstrap-theme.min.css"/> 
  <script src="js/bootstrap.min.js"  type="text/javascript"></script>
  <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
<style type="text/css">
  input[type=text],[type=password],select,[type=date],[type=number]{
   
    padding: 12px ;
    border: 1px solid #ccc;
    border-radius: 4px;
    resize: vertical;
  width:70%;
   margin-left:;
}
</style>
 <script>
function validateForm() {
  var y = document.forms["form"]["name"].value; 
  if (y == null || y == "") {
    document.getElementById("errormsg").innerHTML="Name must be filled out.";
    return false;
  }
  if ((y.length < 3) || (y.length > 30))
  {
    document.getElementById("errormsg").innerHTML="Your Character must be 3 to 15 Character.";
    
    document.getElementById('name').focus();
     return false;
   }

  
    var pattern1 = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern1.test(document.form.name.value)) 
      {
       document.getElementById("errormsg").innerHTML="please enter a valid name.";
      document.getElementById('name').focus();
    return false;
  }
  
  
  var g = document.forms["form"]["email"].value;
  if (g=="") {
    document.getElementById("errormsg").innerHTML="Please enter your emailid";
    document.getElementById('email').focus();
    return false;
  }
  var email = document.form.email.value;
  atpos = email.indexOf("@");
  dotpos = email.lastIndexOf(".");
  if (email == "" || atpos < 1 || ( dotpos - atpos < 2 )) 
  {
     document.getElementById("errormsg").innerHTML="Please enter a valid email id";
   document.getElementById('email').focus();
     return false;
  }

   var p = document.forms["form"]["mobile"].value;
  if (p=="" && p.length != 10) {
    
    document.getElementById("errormsg").innerHTML="Phone number must be 10 digits long";
     document.getElementById('mobile').focus();
    return false;
    
  }
  if (p.length<0) {
     
    document.getElementById("errormsg").innerHTML="Phone number must be 10 digits long";
    document.getElementById('mobile').focus();
    return false;
    
  }
  var x = document.forms["form"]["uname"].value;
  if (x.length == 0) {
    document.getElementById("errormsg").innerHTML="Please enter a valid username";
    return false;
  }
  if (x.length < 4) {
    document.getElementById("errormsg").innerHTML="Username must be at least 4 characters long";
    return false;
  }
  var pattern1 = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern1.test(document.form.uname.value)) 
      {
       document.getElementById("errormsg").innerHTML="please enter a valid name.";
      document.getElementById('uname').focus();
    return false;
  }
  
  var a = document.forms["form"]["pass"].value;
  if(a == null || a == ""){
    document.getElementById("errormsg").innerHTML="Password must be filled out";
    return false;
  }
  if(a.length<5 || a.length>15){
    document.getElementById("errormsg").innerHTML="Passwords must be 5 to 15 characters long.";
    return false;
  }


var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})"); 
  if(!strongRegex.test(document.form.pass.value)) 
      {
        document.getElementById("errormsg").innerHTML="Error: password should contain atleast one uppercase,lowercase ,digit and special characters!";
      
      form.pass.focus();
    return false;
     } 
   
  var b = document.forms["form"]["cpass"].value;
  if (a!=b){
    document.getElementById("errormsg").innerHTML="Passwords must match.";
    return false;
  }
  var cat = document.forms["form"]["cat_id"].value;
  if(cat==-1)
{
document.getElementById("errormsg").innerHTML="plz select";

return false;
  }
}
</script> 
</head>
<body background="b.jpg">


<div class="bg1">
<div class="row">

<div class="col-md-7"></div>
<div class="col-md-4 panel"> 
  <form class="form-horizontal" name="form" action=" "  onSubmit="return validateForm()" method="POST">
<fieldset>
<div class="form-group">
  <label class="col-md-12 control-label" for="name"></label>  
  <div class="col-md-12">
  <h3 align="left">Registration Form</h3>
    
  </div>
</div>

<div class="form-group">
  <label class="col-md-12 control-label" for="name"></label>  
  <div class="col-md-12">
  <div id="errormsg" style="font-size:14px;font-family:calibri;font-weight:normal;color:red"><?php
if (@$_GET['q7']) {
    echo '<p style="color:red;font-size:15px;">' . @$_GET['q7'];
}
?></div>
    
  </div>
</div>
<form method="post" id="framework_form" action=" ">

<center>

    <input type="text" name="name" id="name" placeholder="name" onblur="return validateForm()"><br><br>

    <input type="text" name="email" id="email" placeholder="email" onblur="return validateForm()"><br><br>
    <input type="number" name="mobile" id="mobile" placeholder="mobile" onblur="return validateForm()"><br><br>
    <input type="text" name="uname" id="uname" placeholder="username" onblur="return validateForm()"><br><br>
    <input type="password" name="pass" id="pass" placeholder="password" onblur="return validateForm()" ><br><br>
    <input type="password" name="cpass" id="cpass" placeholder="confirm" onblur="return validateForm()"><br><br>
    
    <div class="form-group">
     
     <?php
    $select="select * from cat";
    $res=mysqli_query($con,$select);
    ?>
     <select id="cat_id" name="cat_id[]" multiple class="form-control"
     required="please select Catogory"  onblur="return validateForm()" >
      <?php
                   while($row=mysqli_fetch_array($res))
                      {

                        ?>
                      <option value="<?php echo $row['cat_id'];?>"><?php echo $row['cat_name'];?></option>
           
                      <?php
                      }
   ?>
     </select>
    </div>

    <?php
    $select="select * from course";
    $res=mysqli_query($con,$select);
    ?>
    <select  name="elig" id="elig" required="please select Your Eligibility" onblur="return validateForm()"  ><option value="" >select your Eligibility</option>
                 <?php
                   while($row=mysqli_fetch_array($res))
                      {

                        ?>
                      <option value="<?php echo $row['cid'];?>"><?php echo $row['cname'];?></option>
           
                      <?php
                      }
   ?></select><br>


         <?php
    $select="select * from center";
     $res=mysqli_query($con,$select);

     ?>
    <select  name="center"  id="center" required="please select a center" onblur="return validateForm()">
      <option value="">select your Exam center</option>
                       <?php
     while($row=mysqli_fetch_array($res))
   {

   ?>
       <option value="<?php echo $row['cen_name'];?>"><?php echo $row['cen_name'];?></option>
           
    <?php
    }
      ?></select>
<br><br><br>
    <div class="form-group">
     <input type="submit" class="btn btn-info" name="submit" value="Submit" />
    </div>
   </form>
</div>
</div></div>
</div>
</center>
</body>
</html>
<script>
$(document).ready(function(){
 $('#cat_id').multiselect({
  nonSelectedText: 'Select Exams',
  enableFiltering: true,
  enableCaseInsensitiveFiltering: true,
  buttonWidth:'300px'
 });
 });
</script>


<?php

 if(isset($_POST['submit']))
  {
     $name = $_POST['name'];
     $uname= $_POST['uname'];
     $pass = $_POST['pass'];
     $mobile = $_POST['mobile']; 
     $email = $_POST['email'];
     
     $elig = $_POST['elig'];
     $center = $_POST['center'];
     
       $ps=md5($pass);

$str="insert into login set uname='$uname',pass='$ps',type='S'";
       if((mysqli_query($con,$str)))  {
      
      
         } 

$result = mysqli_query($con,"SELECT * FROM `login` WHERE uname='$uname' and pass ='$ps'");
   $row  = mysqli_fetch_array($result);
   if(is_array($row))
   {
   $_SESSION["loginid"] = $row['loginid'];

  // /
  } 
   else 
   {

   }

 $loginid = $_SESSION['loginid'];


        $sql="insert into reg set loginid='$loginid',name='$name',email='$email',mobile='$mobile'";
     
       if((mysqli_query($con,$sql))) 
        {
      
      
        }


  
if(isset($_POST["cat_id"]))
{
 $cat_id = '';
 foreach($_POST["cat_id"] as $row)
 {
  $cat_id .= $row . ', ';
 }
 $cat_id = substr($cat_id, 0, -2);
 // $query = "INSERT INTO student(cat_id) VALUES('".$cat_id."')";
 // if(mysqli_query($con, $query))
 // {
  
 // }

           
      
       
$sq="insert into student set loginid='$loginid',elig='$elig',center='$center',cat_id='$cat_id'";
     
       if((mysqli_query($con,$sq))) 
        {
   echo "<script> 
alert('saved');

window.location.href='regs.php';
</script>";        }

      }
 
    
     }
 
?>