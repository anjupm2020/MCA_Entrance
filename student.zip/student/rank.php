
<?php
include 'co.php';
include 'uheader.html';
session_start();
     

?>

<!DOCTYPE html>
<html lang="en">
<head>
    
    <style type="text/css">
  table {
  border-collapse: collapse;
  width: 60%;
  margin-top:40px;
  
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}
</style>
</head>
<body><br><br>
    <center>
       <h1>Ranklist</h1></center> 
    
<center>
<?php
$select="SELECT reg.name,history.total FROM `reg`,`history` WHERE reg.loginid=history.loginid  ORDER BY history.total DESC  ";
$res=mysqli_query($con,$select);
?>
<table border="1" width="75%" >
    <th style="color:red">Name</th>
    <th style="color:red">Rank</th>
<?php
while($row=mysqli_fetch_array($res))
{

?>
<tr>
<td><?php echo $row['name'];?></td>
<td><?php echo $row['total'];?></td>

</tr>
<?php
}
?>
</table></center>
</body>
</html>