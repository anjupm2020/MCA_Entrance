<?php
include 'co.php';
include 'uheader.html';
session_start();
$loginid = $_SESSION['loginid'];
?>

<!DOCTYPE html>
<html>
<head>
  <title></title>
<style type="text/css">
  table {
  border-collapse: collapse;
  width: 40%;
  margin-top:100px;
  
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom:0px solid #ddd;
}
</style>

</head>
<body>

<h1>Result</h1>

<?php
$score=0;

$qry3 = "SELECT * from `answers` where loginid='$loginid'  ";
$result3 = mysqli_query($con,$qry3);



while ($row3=mysqli_fetch_array($result3)) {



       $a=$row3['ans'];
       $b=$row3['userans'];
     if($a==$b)
     {
       $score+=1;
       $rights = $score;
     }
else{
    

    
} }


$q=mysqli_query($con,"SELECT * FROM quiz  " ); 
?>
<center>
<table>

  <th></th>
  <th></th>
<?php
      while($row=mysqli_fetch_array($q) )
      {
        $ri=$row['correct'];
        $wr=$row['wrong'];
        $to=$row['total'];
      }

   $rights = $score;
$wrong= $to-$rights;
      $point=$ri*$rights;
      $points=$wrong*$wr;

   ?>
<br>

<tr>
<td style="font-size:20px;"><?php echo "No. of Right Answers=" ?></td>
<td style="font-size:20px; color: red;"><?php echo $rights ?></td>
</tr>
<tr><td style="font-size:20px;"><?php echo "No. of wrong Answers="?></td>
  <td style="font-size:20px; color: red;;"><?php echo $wrong= $to-$rights ?></td>
  <!-- <tr><td style="font-size:20px;"><?php echo "Score=" ?></td>
    <td style="font-size:20px;color: red;"><?php echo $point=$ri*$rights ?></td></tr> -->
    <tr><td style="font-size:20px;"><?php echo "Total Score="?></td>
      <td style="font-size:20px;color:blue;"><?php echo $total=$point-$points ?></td>
      </tr>
 
 <?php
  $q=mysqli_query($con,"UPDATE `history` SET `rights`=$rights,`wrong`=$wrong,`total`=$total   WHERE   loginid = '$loginid'")or die('Error124');
 ?> 
       

  <!-- ?> -->
  </center>
  </table></body>
</html>

</tr>
<?php
include 'footer.html';
?>
