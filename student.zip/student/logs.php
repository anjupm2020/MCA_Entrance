<?php
include('co.php') ;
session_start();
$loginid = $_SESSION['loginid'];

echo "<script>


window.location.href='login.php';
</script>";
?>