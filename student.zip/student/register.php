<?php
session_start();
include 'co.php';
include 'headers.html';
?>
<!DOCTYPE html>
<html>
<head>
<!-- <link rel="stylesheet" type="text/css" href="style.css"> -->  -->
 <!-- <script type="text/javascript" src="regval.js"></script>  -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />

</head>


<body bgcolor="black"><center>


<div class="frm">
<div class="container">
  <form name="myform" action="reg.php" enctype="multipart/form-data"   method="post" onsubmit="return myfunction()">
  <fieldset >
<legend><h2><font color="white">Register</font></h2></legend><br>

<font size="3" color="white">
      <div class="row">
        <div class="col-25">
           <label >Full Name:</label>
          </div>
           <div class="col-75">
            <input type="text" id="name"  name="name" placeholder="name.."  >
            </div>
    </div>
    
    <div class="row">
      <div class="col-25">
        <label >Email Id:</label>
      </div>
      <div class="col-75">
        <input type="text" id="email"  name="email" placeholder="email.." >
      </div>
    </div>
    


    <div class="row">
      <div class="col-25">
        <label >Mobile No:</label>
      </div>
      <div class="col-75">
       <input name="mobile" id="mobile"  type="number" placeholder="mobile number" >
      </div>
    </div>
    


    
    


    <div class="row">
      <div class="col-25">
        <label >Username:</label>
      </div>
      <div class="col-75">
        <input type="text" id="uname" name="uname" placeholder="username.." >
      </div>
    </div>
    

    <div class="row">
      <div class="col-25">
        <label > password:</label>
      </div>
      <div class="col-75">
        <input type="password" id="pass" name="pass" placeholder="password" >
      </div>
    </div>
     

     <div class="row">
      <div class="col-25">
        <label > Confirm password:</label>
      </div>
      <div class="col-75">
        <input type="password" id="cpwd"  name="cpwd" placeholder="password" >
      </div>
    </div>
 <?php
    $select="select * from center";
     $res=mysqli_query($con,$select);

     ?>
    <br><br><br>
    <div class="row      <div class="col-25">
        <label > Occupation:</label>
      </div>
      <div class="col-75">
        <?php
    $select="select * from cat";
    $res=mysqli_query($con,$select);
    ?>
     <select id="cat_id" name="cat_id[]" multiple class="form-control" >
      <?php
                   while($row=mysqli_fetch_array($res))
                      {

                        ?>
                      <option value="<?php echo $row['cat_id'];?>"><?php echo $row['cat_name'];?></option>
           
                      <?php
                      }
   ?>
      
    </div>

    
    <br><br>
 
    <div class="row">
     <center><input type="submit" value="NEXT" name="submit" ></center><br>
    </div>
    
    
</fieldset>
  </form>
</center>
</font>
</body>
</html>
<script>
$(document).ready(function(){
 $('#cat_id').multiselect({
  nonSelectedText: 'Select Exams',
  enableFiltering: true,
  enableCaseInsensitiveFiltering: true,
  buttonWidth:'100px'
 });
 });
 </script>
 
   <?php

 if(isset($_POST['submit']))
  {
     





 $name = $_POST['name'];
     $uname= $_POST['uname'];
     $pass = $_POST['pass'];
     $mobile = $_POST['mobile']; 
     
        $email = $_POST['email'];
     $type = $_POST['type'];
 $ps=md5($pass);

         $str="insert into login set uname='$uname',pass='$ps',type='$type'";
       if((mysqli_query($con,$str)))  {
      // echo "<center><h3><script>alert('Congrats.. You have successfully registered !!');</script></h3></center>";
      
         } 

$result = mysqli_query($con,"SELECT * FROM `login` WHERE uname='$uname' and pass ='$ps'");
   $row  = mysqli_fetch_array($result);
   if(is_array($row))
   {
   $_SESSION["loginid"] = $row['loginid'];

  // /header("location: home.php");
  } 
   else 
   {

   }

 $loginid = $_SESSION['loginid'];


        $sql="insert into reg set loginid='$loginid',name='$name',email='$email',mobile='$mobile'";
     
       if((mysqli_query($con,$sql))) 
        {
      // echo "<center><h3><script>alert('Congrats.. You have successfully registered !!');</script></h3></center>";
      
        }


  

           
      
       $dir='photo/';
$target_file=$dir.basename($_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'], $target_file);

      
      $sql="INSERT INTO `product` (`loginid`,`image`) VALUES ('$loginid','$target_file')";
      $ch=mysqli_query($con,$sql);
     if($ch)

{
  
  
}


     } 
 
?>