function myfunction()
{
var x=document.forms["myform"]["name"].value;
if(x=="")
{
alert("Please Fill name Field");
document.getElementById('name').focus();
return false;
}
 
 if ((x.length < 3) || (x.length > 30))
  {
    alert("Your Character must be 3 to 15 Character");
    document.getElementById('name').focus();
     return false;
   }

  
    var pattern1 = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern1.test(document.myform.name.value)) 
      {
      alert("Error: Please enter valid name!");
      myform.name.focus();
    return false;
     
}
 
var x=document.forms["myform"]["dob"].value;
if(x=="")
{
alert("Please select your birthday");
document.getElementById('dob').focus();
return false;
}



   var e=document.forms["myform"]["email"].value;
if(e=="")
{
alert("Please Fill emailid Field");
document.getElementById('email').focus();
return false;
}
var email = document.myform.email.value;
  atpos = email.indexOf("@");
  dotpos = email.lastIndexOf(".");
  if (email == "" || atpos < 1 || ( dotpos - atpos < 2 )) 
  {
     alert("Please enter correct email ID")
   document.getElementById('email').focus();
     return false;
  }



if( document.myform.mobile.value == "" ||
           isNaN( document.myform.mobile.value) ||
           document.myform.mobile.value.length != 10 )
   {
     alert( "Please provide a valid Mobile Number upto 10 digit" );
   document.getElementById('mobile').focus();
     return false;
   }
   var pattern = new RegExp("^([6-9]{1})([0-9]{9})$"); 
      if(!pattern.test(document.myform.mobile.value)) 
      {
      alert("Error: Phone Number is invalid!");
      myform.mobile.focus();
    return false;
     }




var f=document.myform.uname.value;
if(f=="")
{
alert("Please Fill username Field");
document.getElementById('uname').focus();
return false;
}

var o=document.myform.pass.value;
if(o=="")
{
alert("Please Fill password Field");
document.getElementById('pass').focus();
return false;
}
if(o.length<8){  
   alert("Password must be at least 8 characters long.");  
   document.getElementById('pass').focus();
    return false;  
}

var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})"); 
  if(!strongRegex.test(document.myform.pass.value)) 
      {
      alert("Error: password should contain atleast one uppercase,lowercase ,digit and special characters!");
      myform.pass.focus();
    return false;
     } 
   
var h=document.myform.cpass.value;
if(h=="")
{
alert("Please Fill confirm password Field");
document.myform.cpass.focus();
return false;
}
var pwd = document.myform.pass.value;
       var cpass = document.myform.cpwd.value;
        if (pass != cpwd) {
            alert("Passwords do not match.");
            document.myform.cpass.focus();
            return false;
        }



var t=document.getElementById("type").value;
if(t==-1)
{
alert("Please select occupation");

return false;
}

return (true);
}