<?php
include 'co.php';
session_start();
include 'headers.html';
$loginid = $_SESSION['loginid'];
extract($_POST);
$type=$_SESSION['type'];

 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.ins
		{
	     width:50%;
	     margin-left:350px; 
	     font-size:20px;
	     margin-top:50px;
		}
		input[type=submit] {

  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 18px;
  padding: 10px;
  width: 100px;
  transition: all 0.5s;
  cursor: pointer;
  margin-left:450px;
}

	</style>
</head>
<body>
	


<p class="ins">
	<br>Each question in the quiz is of multiple-choice  format.<br><br>
 Read each question carefully, and click on the button next to your response that is based on the information covered on the topic in the module.<br><br>
  Each correct or incorrect response will result in appropriate feedback immediately at the bottom of the screen.<br><br>

After responding to a question, click on the "Next Question" button at the bottom to go to the next questino.<br><br>
The total score for the quiz is based on your responses to all questions.
</p>

<form method="post" action="update_history.php">
	<input type="submit" name="submit" value="Accept">
</form>

</body>
</html>