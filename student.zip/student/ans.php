<?php
include 'co.php';
include 'uheader.html';
session_start();
$loginid=$_SESSION['loginid'];?>

<html>
<head>
   <style type="text/css">
       .one
       {
        width:50%;
        margin-left:150px;
        align-content:center;
       }
   </style> 
    

 
  <script src="js/bootstrap.min.js"  type="text/javascript"></script>
</head>
<body> <center>
    <h1>Answers</h1>

<div class="one">
<?php
$select="SELECT question.qn,question.qno,answers.qno,answers.ans,answers.userans FROM `question`,`answers` where question.qno=answers.qno and answers.loginid='$loginid'";
$res=mysqli_query($con,$select);


while($row=mysqli_fetch_array($res))
{
     
     $ans=$row['ans'];
     $userans=$row['userans'];
     $qn=$row['qn'];

if ($ans == $userans && $userans != "Unanswered") {
                echo '<div style="font-size:16px;font-weight:bold;font-family:calibri;margin-top:20px;background-color:lightgreen;padding:10px;word-wrap:break-word;border:2px solid darkgreen;border-radius:10px;">' . $qn . ' 
                <span class="glyphicon glyphicon-ok" style="color:darkgreen"></span></div><br />';
                echo '<font style="font-size:14px;color:darkgreen"><b>Your Answer: </b></font><font style="font-size:14px;">' . $ans . '</font><br />';
                echo '<font style="font-size:14px;color:darkgreen"><b>Correct Answer: </b></font><font style="font-size:14px;">' . $userans . '</font><br />';
            } 
            else if ($ans == "Unanswered") {
                echo '<li><div style="font-size:16px;font-weight:bold;font-family:calibri;margin-top:20px;background-color:#f7f576;padding:10px;word-wrap:break-word;border:2px solid #b75a0e;border-radius:10px;">' . $qn . ' </div><br />';
                echo '<font style="font-size:14px;color:darkgreen"><b>Correct Answer: </b></font><font style="font-size:14px;">' . $ans . '</font><br />';
            } 
            else {
                echo '<div style="font-size:16px;font-weight:bold;font-family:calibri;margin-top:20px;background-color:#f99595;padding:10px;word-wrap:break-word;border:2px solid darkred;border-radius:10px;">' . $qn . ' <span class="glyphicon glyphicon-remove" style="color:red"></span></div><br />';
                echo '<font style="font-size:14px;color:darkgreen"><b>Your Answer: </b></font><font style="font-size:14px;">' . $userans . '</font><br />';
                echo '<font style="font-size:14px;color:red"><b>Correct Answer: </b></font><font style="font-size:14px;">' . $ans . '</font><br />';
                
            }
            
        }

        ?>
</center></div>
        </body>
        </html>