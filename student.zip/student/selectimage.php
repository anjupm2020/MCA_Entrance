<?php
include("co.php");
  include 'headers.html';
  session_start();

  $loginid=$_SESSION['loginid'];
$select="SELECT * FROM `book` WHERE loginid='$loginid'";
$res=mysqli_query($con,$select);

while($row=mysqli_fetch_array($res))
{
	$_SESSION['type']=$row['cat_id'];
}

$type=$_SESSION['type'];
header('location:showexam.php');
}
?>