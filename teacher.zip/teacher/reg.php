<?php
session_start();
include 'co.php';
include 'headers.html';
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css"> --> 
 <!-- <script type="text/javascript" src="regval.js"></script>  -->


</head>


<body><center>


<div class="frm">
<div class="container">
  <form name="myform" action="reg.php" enctype="multipart/form-data"   method="post" onsubmit="return myfunction()">
	<fieldset >
<legend><h2><font color="white">Register</font></h2></legend><br>

<font size="3" color="white">
      <div class="row">
        <div class="col-25">
           <label >Full Name:</label>
          </div>
           <div class="col-75">
            <input type="text" id="name"  name="name" placeholder="name.."  >
            </div>
    </div>
    
    <div class="row">
      <div class="col-25">
        <label >Email Id:</label>
      </div>
      <div class="col-75">
        <input type="text" id="email"  name="email" placeholder="email.." >
      </div>
    </div>
    


    <div class="row">
      <div class="col-25">
        <label >Mobile No:</label>
      </div>
      <div class="col-75">
       <input name="mobile" id="mobile"  type="number" placeholder="mobile number" >
      </div>
    </div>
    


    
    


    <div class="row">
      <div class="col-25">
        <label >Username:</label>
      </div>
      <div class="col-75">
        <input type="text" id="uname" name="uname" placeholder="username.." >
      </div>
    </div>
    

    <div class="row">
      <div class="col-25">
        <label > password:</label>
      </div>
      <div class="col-75">
        <input type="password" id="pass" name="pass" placeholder="password" >
      </div>
    </div>
     

     <div class="row">
      <div class="col-25">
        <label > Confirm password:</label>
      </div>
      <div class="col-75">
        <input type="password" id="cpwd"  name="cpwd" placeholder="password" >
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label > Occupation:</label>
      </div>
      <div class="col-75">
        <select  name="type" id="type" >
            <option value="-1">select your occupation</option>
            <option value="S">Student</option>
            <option value="T">Teacher</option>
                              
        </select>
      </div>
    </div>

    <div class="row">
      <div class="col-25">

        <label > Upload Your Photo:</label>
      </div>
      <div class="col-75">
        
       <input type="file" name="file" class="form-control" placeholder="upload image"><br><br>
        

      </div> 
    </div>
    <br><br>
 
    <div class="row">
     <center><input type="submit" value="NEXT" name="submit" ></center><br>
    </div>
    
    
</fieldset>
  </form>
</center>
</font>
</body>
</html>

 
   <?php

 if(isset($_POST['submit']))
  {
     





 $name = $_POST['name'];
     $uname= $_POST['uname'];
     $pass = $_POST['pass'];
     $mobile = $_POST['mobile']; 
     
        $email = $_POST['email'];
     $type = $_POST['type'];
 $ps=md5($pass);

         $str="insert into login set uname='$uname',pass='$ps',type='$type'";
       if((mysqli_query($con,$str)))  {
      // echo "<center><h3><script>alert('Congrats.. You have successfully registered !!');</script></h3></center>";
      
         } 

$result = mysqli_query($con,"SELECT * FROM `login` WHERE uname='$uname' and pass ='$ps'");
   $row  = mysqli_fetch_array($result);
   if(is_array($row))
   {
   $_SESSION["loginid"] = $row['loginid'];

  // /header("location: home.php");
  } 
   else 
   {

   }

 $loginid = $_SESSION['loginid'];


        $sql="insert into reg set loginid='$loginid',name='$name',email='$email',mobile='$mobile'";
     
       if((mysqli_query($con,$sql))) 
        {
      // echo "<center><h3><script>alert('Congrats.. You have successfully registered !!');</script></h3></center>";
      
        }


  

           
      
       $dir='photo/';
$target_file=$dir.basename($_FILES['file']['name']);
move_uploaded_file($_FILES['file']['tmp_name'], $target_file);

      
      $sql="INSERT INTO `product` (`loginid`,`image`) VALUES ('$loginid','$target_file')";
      $ch=mysqli_query($con,$sql);
     if($ch)

{
  
  
}

if($type=='S')
           {
            header("location: student.php");
           }
           else
           {
            header("location:teacher.php");  
           }
     } 
 
?>