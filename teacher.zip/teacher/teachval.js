function formValidation()
{


	 var a = document.registration.sub.value;
	var b = document.registration.col.value;


if(a=="")
{
alert("Please Enter Your Subject");

return false;
}
if(!isNaN(a))
{
alert("Please Enter Only Characters");

return false;
}

if(b=="")
{
alert("Please Enter Your College Name");

return false;
}
if(!isNaN(b))
{
alert("Please Enter Only Characters");

return false;
}
}